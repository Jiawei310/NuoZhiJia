package no.nordicsemi.android.nrftoolbox.uart;


public interface UARTInterface {

	public void send(final String text);
}
