//
//  BluetoothInfo.m
//  iHappySleep
//
//  Created by 诺之家 on 15/11/2.
//  Copyright (c) 2015年 诺之家. All rights reserved.
//

#import "BluetoothInfo.h"

@implementation BluetoothInfo

@end
