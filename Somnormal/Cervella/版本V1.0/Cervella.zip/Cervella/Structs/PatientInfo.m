//
//  PatientInfo.m
//  iHappySleep
//
//  Created by 诺之家 on 15/10/9.
//  Copyright (c) 2015年 诺之家. All rights reserved.
//

#import "PatientInfo.h"

@implementation PatientInfo

@synthesize  PatientID,PatientPwd,PatientName,PatientSex,CellPhone,Birthday;
@synthesize  PatientContactWay,FamilyPhone,Email,PatientRemarks,Vocation;
@synthesize  BloodModel,Picture,Age,Address,NativePlace,Marriage;
@synthesize  PatientHeight,PatientWeight,PhotoUrl;

@end
