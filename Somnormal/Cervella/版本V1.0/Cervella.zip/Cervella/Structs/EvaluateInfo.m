//
//  SleepEvaluateInfo.m
//  iHappySleep
//
//  Created by 诺之家 on 15/10/27.
//  Copyright (c) 2015年 诺之家. All rights reserved.
//

#import "EvaluateInfo.h"

@implementation EvaluateInfo

@end
