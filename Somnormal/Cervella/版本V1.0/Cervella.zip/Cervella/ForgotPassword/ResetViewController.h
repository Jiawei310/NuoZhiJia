//
//  ResetViewController.h
//  Cervella
//
//  Created by Justin on 2017/6/28.
//  Copyright © 2017年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResetViewController : UIViewController

@property (strong, nonatomic) PatientInfo *patientInfo;

@end
