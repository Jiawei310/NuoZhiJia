//
//  ForgotPasswordViewController.h
//  Cervella
//
//  Created by Justin on 2017/6/27.
//  Copyright © 2017年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPasswordViewController : UIViewController

@property (strong, nonatomic) PatientInfo *patientInfo;

@end
