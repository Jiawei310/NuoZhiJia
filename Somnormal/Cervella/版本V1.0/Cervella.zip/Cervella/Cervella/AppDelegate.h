//
//  AppDelegate.h
//  Cervella
//
//  Created by Justin on 2017/6/26.
//  Copyright © 2017年 Justin. All rights reserved.
//

// 诺之嘉：com.nuozhijia.Cervella
// 美国：com.nzj.Cervella

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

