//
//  MyInfoViewController.h
//  Cervella
//
//  Created by Justin on 2017/7/7.
//  Copyright © 2017年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyInfoViewController : UIViewController

@property (nonatomic, strong) PatientInfo *patientInfo;

@end
