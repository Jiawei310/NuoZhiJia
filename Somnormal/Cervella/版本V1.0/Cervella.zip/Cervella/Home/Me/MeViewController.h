//
//  MeViewController.h
//  Cervella
//
//  Created by Justin on 2017/6/29.
//  Copyright © 2017年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeViewController : UIViewController

@property (nonatomic, strong) PatientInfo *patientInfo;

@end
