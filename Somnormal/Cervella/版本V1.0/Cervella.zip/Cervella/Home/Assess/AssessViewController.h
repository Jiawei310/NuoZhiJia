//
//  AssessViewController.h
//  Cervella
//
//  Created by Justin on 2017/6/29.
//  Copyright © 2017年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PatientInfo.h"
#import "EvaluateInfo.h"

@interface AssessViewController : UIViewController

@property (nonatomic, strong) PatientInfo *patientInfo;

@end
