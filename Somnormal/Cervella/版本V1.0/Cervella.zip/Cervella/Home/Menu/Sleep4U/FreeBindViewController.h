//
//  FreeBindViewController.h
//  iHappySleep
//
//  Created by 诺之家 on 15/11/8.
//  Copyright (c) 2015年 诺之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FreeBindViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *Label_One;
@property (strong, nonatomic) IBOutlet UILabel *Label_Two;
@property (strong, nonatomic) IBOutlet UIButton *FreeBindButton;

@end
