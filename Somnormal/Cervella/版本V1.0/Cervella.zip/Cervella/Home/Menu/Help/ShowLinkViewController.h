//
//  ShowLinkViewController.h
//  Cervella
//
//  Created by Song on 2018/6/24.
//  Copyright © 2018年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowLinkViewController : UIViewController

@property (nonatomic, strong) NSString *linkStr;
@end
