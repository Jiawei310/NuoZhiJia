//
//  AboutCervellaViewController.h
//  Cervella
//
//  Created by 一磊 on 2018/6/15.
//  Copyright © 2018年 Justin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutCervellaViewController : UIViewController

@end
