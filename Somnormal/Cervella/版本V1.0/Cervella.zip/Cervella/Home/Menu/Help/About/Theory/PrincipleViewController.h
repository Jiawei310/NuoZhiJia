//
//  PrincipleViewController.h
//  iHappySleep
//
//  Created by 诺之家 on 15/12/25.
//  Copyright © 2015年 诺之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrincipleViewController : UIViewController

@end
