//
//  ConfigAnswerViewController.h
//  iHappySleep
//
//  Created by 诺之家 on 15/11/20.
//  Copyright (c) 2015年 诺之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfigAnswerViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property NSDictionary *answerDic;

@end
