//
//  UIButton+Common.h
//  iHappySleep
//
//  Created by 诺之家 on 15/12/21.
//  Copyright © 2015年 诺之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Common)

@property (nonatomic,strong,readwrite) NSString *btnFlag;

@end
