//
//  CircleView.h
//  CircleChart
//
//  Created by 诺之家 on 15/12/8.
//  Copyright © 2015年 诺之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircleView : UIView

@property CGFloat radiansVeryGood;
@property CGFloat radiansGeneral;
@property CGFloat radiansBad;
@property CGFloat radiansVeryBad;

@end
